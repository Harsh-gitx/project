import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeComponent } from './home.component';
import { HomeService } from './home.service';
import { HttpClientModule } from '@angular/common/http';
import {MatToolbarModule} from '@angular/material/toolbar';
import { MatCardModule } from '@angular/material/card';
import { CardetailsComponent } from './cardetails/cardetails.component';
import {MatSidenavModule} from '@angular/material/sidenav';
import { CarroutingModule } from '../carrouting/carrouting.module';
import {MatButtonModule} from '@angular/material/button';
import {MatDividerModule} from '@angular/material/divider';
import { StoresComponent } from './stores/stores.component';
import { CartComponent } from './cart/cart.component';
import { PaymentComponent } from './payment/payment.component';
import {MatRadioModule} from '@angular/material/radio';
import { FormsModule } from '@angular/forms';
import {MatBadgeModule} from '@angular/material/badge';
import {MatDialogModule} from '@angular/material/dialog';
import { DialogComponent } from './cardetails/dialog/dialog.component';
import { MatInputModule } from '@angular/material/input';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import { CreateCarsComponent } from './create-cars/create-cars.component';
@NgModule({
  imports: [
    CommonModule,HttpClientModule,MatToolbarModule,MatCardModule,MatSidenavModule,CarroutingModule,MatButtonModule,MatDividerModule,MatRadioModule,FormsModule,MatBadgeModule
    ,MatDialogModule,MatInputModule,MatSnackBarModule
  ],
  entryComponents:[DialogComponent],
  declarations: [HomeComponent, CardetailsComponent, StoresComponent, CartComponent, PaymentComponent, DialogComponent, CreateCarsComponent],
  providers : [HomeService],
  exports :[HomeComponent]
})
export class HomeModule { }
