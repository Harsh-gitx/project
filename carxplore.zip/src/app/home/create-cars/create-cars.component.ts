import { Component, OnInit } from '@angular/core';
import { CreateCarsService } from './create-cars.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-create-cars',
  templateUrl: './create-cars.component.html',
  styleUrls: ['./create-cars.component.css']
})
export class CreateCarsComponent implements OnInit {

  constructor(private _service:CreateCarsService,private _snackBar:MatSnackBar) { }

  ngOnInit() {
  }
  addCar(userName,password,date){
    this._service.createCars({"name":userName,"price":password,"year":date})
      .subscribe(data=>{
        this._snackBar.open("Added a new car successfully","OK",{
          duration:2000
              })
      })
}
}
