import { TestBed } from '@angular/core/testing';

import { CreateCarsService } from './create-cars.service';

describe('CreateCarsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CreateCarsService = TestBed.get(CreateCarsService);
    expect(service).toBeTruthy();
  });
});
