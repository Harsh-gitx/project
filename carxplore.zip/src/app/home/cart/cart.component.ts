import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  selectedCars=[]
  total
  constructor(private _service:CartService,private _router:Router) { 
    this.selectedCars=this._service.addedCars
    console.log(this.selectedCars)
    this.total=this.selectedCars.reduce((data,acc)=>
    {
       return parseFloat(acc['estimatedPrice'])+data
    }
    ,0)
  }
  navigateToPayment(){
    this._router.navigate(["home/payment"])
  }
  ngOnInit() {
  }

}
