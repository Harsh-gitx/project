import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators'

@Injectable({
  providedIn: 'root'
})
export class CardetailsService {

  storesList=[];
  selectedCar=[];
  constructor(private _http:HttpClient) { }

getCarDetails(url){
  let observableData=this._http.get(url);
  //observableData.pipe(map(data=>console.log(data)));
  return observableData.pipe(map(data=>data['upCommingCars']));
}

getStoreDetails(){
  return this._http.get("https://raw.githubusercontent.com/Harsh-gitx/carXplore/master/Locations.json")
}


}
