import { Component, OnInit } from '@angular/core';
import { CardetailsService } from '../cardetails.service';

@Component({
  selector: 'app-stores',
  templateUrl: './stores.component.html',
  styleUrls: ['./stores.component.css']
})
export class StoresComponent implements OnInit {
  selectedCar=[]
  storesList

  goToLoc(store){
    window.open(store.loc)
   //window.open("https://www.google.com/maps/place/BMW+Navnit+Motors+%7C+Main+Showroom+%7C+Electronic+City/@12.8624043,77.5897209,12z/data=!4m8!1m2!2m1!1sbmw+showroom+near+me!3m4!1s0x3bae6ca1346703e3:0x2bf8c2ef25dc2027!8m2!3d12.8624043!4d77.6597587")

  }
  constructor(private _service:CardetailsService) { 
        console.log(this._service.selectedCar,this._service.storesList)

    this.selectedCar=[this._service.selectedCar]
    let obj=this._service.storesList[0]
    this.storesList=obj[Object.keys(obj)[0]]

  }

  ngOnInit() {
  }

}
