import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
  captcha;
  captchaVal;
  constructor(private _snackBar:MatSnackBar){}
  generateCaptcha=()=>{
    let alphabets=["a","b","c","d"
  ,"e","f","g","h","i","j","k","l","m","n",
  "o","p","q","r","s","t","u","v","w","x","y","z"
  ]
 let a=Math.floor(Math.random()*10)
 let b=Math.floor(Math.random()*10)
 let c=Math.floor(Math.random()*10)
 let d=Math.floor(Math.random()*10)
 let e=Math.floor(Math.random()*10)
 this.captcha=a+""+alphabets[b]+""+alphabets[c]+""+d+""+e
  }

  refresh=()=>{
    this.generateCaptcha()
  }
  ngOnInit() {
    this.generateCaptcha();
  }
  pay=(captchaVal)=>{
if(captchaVal==this.captcha)
    this._snackBar.open("payment Made Successfully","OK",{
      duration:2000
          })

  }
}
