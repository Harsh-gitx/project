import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CardetailsService } from '../cardetails.service';
import { CartService } from '../cart.service';
import { HomeService } from '../home.service';
import { MatDialog } from '@angular/material/dialog';
import { DialogComponent } from './dialog/dialog.component';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-cardetails',
  templateUrl: './cardetails.component.html',
  styleUrls: ['./cardetails.component.css']
})
export class CardetailsComponent implements OnInit {
upComingCars=[];
locations=[];

  constructor(private _route:ActivatedRoute,private dialog:MatDialog,
    private _service: CardetailsService,private _router:Router,private _cartService:CartService,private _homeService:HomeService,
    private _snackBar: MatSnackBar) { }


    openDialog(): void {
      const dialogRef = this.dialog.open(DialogComponent,
        {
          width:"400px",
          data: {key:"Enter Email"}
        }
     
      );
  
      dialogRef.afterClosed().subscribe(result => {
        console.log("done");
      //  this.animal = result;
      });
    }

  locateStore(carDetails){

    this._service.getStoreDetails()
                 .subscribe(data=>{
                   this.locations=data['Locations']
                   this._service.storesList=this.locations.filter(location=>
                    {
                      console.log(carDetails.carName.toLocaleLowerCase(),Object.keys(location)[0].toLocaleLowerCase())
                      return carDetails.carName.toLocaleLowerCase().includes(Object.keys(location)[0].toLocaleLowerCase())

                    });

                   this._service.selectedCar=carDetails;
                   this._router.navigate(['home/storeDetails']);
                 }
                   )
  }
  addToCart(carDetails){
    this._snackBar.open("Added to cart successfully","OK",{
duration:2000
    })
    this._cartService.addedCars.push(carDetails);
    this._homeService.cartTotal=this._cartService.addedCars.length;
  }

  getUpComingCars(){
    let brandDetails=this._route.snapshot.params;
    let brandObj=JSON.parse(brandDetails.brand);
    console.log(brandObj.name);

    this._service.getCarDetails(brandObj.url).subscribe((data)=>{
      console.log(data);
      //console.log(data['upcomingCars']);
      this.upComingCars=data;
      console.log(this.upComingCars[0])
    });

    
  }
  ngOnInit() {
   this._route.params.subscribe(data=>this.getUpComingCars());
  }

}
