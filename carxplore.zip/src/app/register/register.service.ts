import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  constructor(private _service:HttpClient) { }

  saveUser(userObj){
    return this._service.post("http://localhost:8080/cxcarz/createCustomer.do",userObj);
  }
}
