import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RegisterService } from './register.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})

export class RegisterComponent implements OnInit {

  username : string;
  mobilenum : string;
  mail : string;
  pswd : string;
  cpswd : string;
  gender : string;

  constructor(private _router:Router,private _service:RegisterService) { }

  formSubmit(){
    //alert();
    console.log(this.username);
    console.log(this.mobilenum);
    console.log(this.mail);
    console.log(this.pswd);
    const user={
      userName:this.username,
      mobilenum:this.mobilenum,
      emailId:this.mail,
      password:this.pswd,
      gender:this.gender
    }
    this._service.saveUser(user).subscribe(data=>
      {
        localStorage.setItem(this.mail,JSON.stringify(user));
      }
      )
      localStorage.setItem(this.mail,JSON.stringify(user));
    
    this._router.navigate(['/login']);
  }

  navigateToLogin(){
    this._router.navigate(['login']);
  }


  ngOnInit() {
  }

}
